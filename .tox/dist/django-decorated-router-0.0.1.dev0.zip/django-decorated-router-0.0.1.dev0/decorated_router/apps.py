from django.apps import AppConfig


class DecoratedRouterConfig(AppConfig):
    name = 'decorated_router'
